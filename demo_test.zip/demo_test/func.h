#ifndef FUNC_H
#define FUNC_H

#include <QWidget>
#include <QTcpSocket>

#include <QtCharts>   //图表头文件
using namespace QtCharts;

namespace Ui {
class Func;
}

class Func : public QWidget
{
    Q_OBJECT

public:
    explicit Func(QWidget *parent = nullptr);
    ~Func();
    unsigned char buf_LED[20]={0xAA,0xB1,0x00,0x01};
    float value;

private slots:
    void on_pushButton_clicked();
    void slot_connected();
    void slot_readyRead();

    void on_pushButton_openFM_clicked();
    void on_pushButton_closeFM_clicked();


    void on_comboBox_activated(const QString &arg1);

    void on_pushButton_openLED_clicked();

    void on_pushButton_closeLED_clicked();

    void on_pushButton_getTem_clicked();

    void on_pushButton_device_clicked();

private:
       Ui::Func *ui;
       QTcpSocket *TcpSocket;
       QTcpSocket *TcpSocket_2;

       QChartView * chartview = new QChartView(this);
       QLineSeries * seriesS = new QLineSeries();
       QChart * mChart;
       int i=0;
};

#endif // FUNC_H
