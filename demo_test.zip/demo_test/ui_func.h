/********************************************************************************
** Form generated from reading UI file 'func.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FUNC_H
#define UI_FUNC_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>
#include <qchartview.h>

QT_BEGIN_NAMESPACE

class Ui_Func
{
public:
    QTabWidget *tabWidget;
    QWidget *widget;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_3;
    QWidget *tab_2;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_device;
    QLineEdit *lineEdit_4;
    QLabel *label_4;
    QLabel *label_5;
    QGroupBox *groupBox;
    QPushButton *pushButton_openLED;
    QPushButton *pushButton_closeLED;
    QPushButton *pushButton_openFM;
    QPushButton *pushButton_closeFM;
    QLabel *label_7;
    QComboBox *comboBox;
    QGroupBox *groupBox_2;
    QPushButton *pushButton_getTem;
    QLabel *label_6;
    QLineEdit *lineEdit_Temp;
    QChartView *ChartView;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_8;
    QLabel *label_9;

    void setupUi(QWidget *Func)
    {
        if (Func->objectName().isEmpty())
            Func->setObjectName(QStringLiteral("Func"));
        Func->resize(892, 662);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../pic/\347\233\221\346\216\247.png"), QSize(), QIcon::Normal, QIcon::Off);
        Func->setWindowIcon(icon);
        tabWidget = new QTabWidget(Func);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 891, 661));
        widget = new QWidget();
        widget->setObjectName(QStringLiteral("widget"));
        widget->setStyleSheet(QLatin1String("#widget{\n"
"	\n"
"	border-image: url(:/new/prefix1/pic/background-3.png);\n"
"}"));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 60, 81, 31));
        QFont font;
        font.setPointSize(15);
        label->setFont(font);
        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(400, 60, 71, 31));
        label_2->setFont(font);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(740, 50, 101, 41));
        QFont font1;
        font1.setPointSize(14);
        pushButton->setFont(font1);
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(120, 50, 241, 41));
        lineEdit->setFont(font);
        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(490, 50, 221, 41));
        lineEdit_2->setFont(font);
        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 120, 781, 371));
        label_3->setScaledContents(true);
        tabWidget->addTab(widget, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tab_2->setStyleSheet(QLatin1String("#tab_2{\n"
"	\n"
"	\n"
"	border-image: url(:/new/prefix1/pic/background-3.png);\n"
"	\n"
"\n"
"}"));
        lineEdit_3 = new QLineEdit(tab_2);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(490, 30, 221, 41));
        lineEdit_3->setFont(font);
        pushButton_device = new QPushButton(tab_2);
        pushButton_device->setObjectName(QStringLiteral("pushButton_device"));
        pushButton_device->setGeometry(QRect(740, 30, 101, 41));
        pushButton_device->setFont(font1);
        lineEdit_4 = new QLineEdit(tab_2);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(120, 30, 241, 41));
        lineEdit_4->setFont(font);
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(400, 40, 71, 31));
        label_4->setFont(font);
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(20, 40, 81, 31));
        label_5->setFont(font);
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(30, 90, 381, 131));
        QFont font2;
        font2.setPointSize(12);
        groupBox->setFont(font2);
        pushButton_openLED = new QPushButton(groupBox);
        pushButton_openLED->setObjectName(QStringLiteral("pushButton_openLED"));
        pushButton_openLED->setGeometry(QRect(120, 30, 101, 41));
        pushButton_openLED->setFont(font);
        pushButton_closeLED = new QPushButton(groupBox);
        pushButton_closeLED->setObjectName(QStringLiteral("pushButton_closeLED"));
        pushButton_closeLED->setGeometry(QRect(250, 30, 101, 41));
        pushButton_closeLED->setFont(font);
        pushButton_openFM = new QPushButton(groupBox);
        pushButton_openFM->setObjectName(QStringLiteral("pushButton_openFM"));
        pushButton_openFM->setGeometry(QRect(120, 80, 101, 41));
        pushButton_openFM->setFont(font);
        pushButton_closeFM = new QPushButton(groupBox);
        pushButton_closeFM->setObjectName(QStringLiteral("pushButton_closeFM"));
        pushButton_closeFM->setGeometry(QRect(250, 80, 101, 41));
        pushButton_closeFM->setFont(font);
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(30, 80, 81, 31));
        label_7->setFont(font);
        comboBox = new QComboBox(groupBox);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(10, 30, 101, 41));
        comboBox->setFont(font1);
        groupBox_2 = new QGroupBox(tab_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(430, 90, 411, 131));
        groupBox_2->setFont(font2);
        pushButton_getTem = new QPushButton(groupBox_2);
        pushButton_getTem->setObjectName(QStringLiteral("pushButton_getTem"));
        pushButton_getTem->setGeometry(QRect(20, 80, 371, 41));
        pushButton_getTem->setFont(font);
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 30, 101, 31));
        label_6->setFont(font1);
        lineEdit_Temp = new QLineEdit(groupBox_2);
        lineEdit_Temp->setObjectName(QStringLiteral("lineEdit_Temp"));
        lineEdit_Temp->setEnabled(true);
        lineEdit_Temp->setGeometry(QRect(100, 29, 271, 41));
        lineEdit_Temp->setFont(font2);
        ChartView = new QChartView(tab_2);
        ChartView->setObjectName(QStringLiteral("ChartView"));
        ChartView->setGeometry(QRect(30, 270, 801, 321));
        horizontalLayoutWidget = new QWidget(ChartView);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(0, 0, 801, 311));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_8 = new QLabel(tab_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(30, 234, 101, 21));
        label_8->setFont(font2);
        label_9 = new QLabel(tab_2);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(7, 4, 871, 631));
        label_9->setStyleSheet(QStringLiteral("border-image: url(:/pic/background-3.png);"));
        tabWidget->addTab(tab_2, QString());
        label_9->raise();
        lineEdit_3->raise();
        pushButton_device->raise();
        lineEdit_4->raise();
        label_4->raise();
        label_5->raise();
        groupBox->raise();
        groupBox_2->raise();
        ChartView->raise();
        label_8->raise();

        retranslateUi(Func);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Func);
    } // setupUi

    void retranslateUi(QWidget *Func)
    {
        Func->setWindowTitle(QApplication::translate("Func", "\345\212\237\350\203\275\347\225\214\351\235\242", Q_NULLPTR));
        label->setText(QApplication::translate("Func", "IP\345\234\260\345\235\200\357\274\232", Q_NULLPTR));
        label_2->setText(QApplication::translate("Func", "\347\253\257\345\217\243\345\217\267\357\274\232", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Func", "\346\267\273\345\212\240\347\233\221\346\216\247", Q_NULLPTR));
        lineEdit->setText(QApplication::translate("Func", "192.168.100.200", Q_NULLPTR));
        lineEdit_2->setText(QApplication::translate("Func", "10000", Q_NULLPTR));
        label_3->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(widget), QApplication::translate("Func", "\346\221\204\345\203\217\345\244\264\350\277\234\347\250\213", Q_NULLPTR));
        lineEdit_3->setText(QApplication::translate("Func", "10001", Q_NULLPTR));
        pushButton_device->setText(QApplication::translate("Func", "\346\267\273\345\212\240\350\256\276\345\244\207", Q_NULLPTR));
        lineEdit_4->setText(QApplication::translate("Func", "192.168.100.200", Q_NULLPTR));
        label_4->setText(QApplication::translate("Func", "\347\253\257\345\217\243\345\217\267\357\274\232", Q_NULLPTR));
        label_5->setText(QApplication::translate("Func", "IP\345\234\260\345\235\200\357\274\232", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("Func", "\350\256\276\345\244\207\346\216\247\345\210\266", Q_NULLPTR));
        pushButton_openLED->setText(QApplication::translate("Func", "\345\274\200", Q_NULLPTR));
        pushButton_closeLED->setText(QApplication::translate("Func", "\345\205\263", Q_NULLPTR));
        pushButton_openFM->setText(QApplication::translate("Func", "\345\274\200", Q_NULLPTR));
        pushButton_closeFM->setText(QApplication::translate("Func", "\345\205\263", Q_NULLPTR));
        label_7->setText(QApplication::translate("Func", "\350\234\202\351\270\243\345\231\250", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("Func", "\350\256\276\345\244\207\351\207\207\351\233\206", Q_NULLPTR));
        pushButton_getTem->setText(QApplication::translate("Func", "\350\216\267\345\217\226\346\270\251\345\272\246", Q_NULLPTR));
        label_6->setText(QApplication::translate("Func", "\345\275\223\345\211\215\346\270\251\345\272\246", Q_NULLPTR));
        label_8->setText(QApplication::translate("Func", "\346\225\260\346\215\256\345\217\257\350\247\206\345\214\226", Q_NULLPTR));
        label_9->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("Func", "\350\256\276\345\244\207\350\277\234\347\250\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Func: public Ui_Func {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FUNC_H
