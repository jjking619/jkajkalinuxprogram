#include "login.h"      //引入自己创建的login.h头文件
#include "ui_login.h"   //引入QT的事件机制头文件：鼠标点击，窗口拖拽
#include <QDebug>
#include <QMessageBox>
#include "func.h"
login::login(QWidget *parent)
    //初始化列表
    : QWidget(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);  //设置UI最顶部显示
    //背景音乐
    Media=new QMediaPlayer(this);
    Media->setMedia(QMediaContent(QUrl("qrc:/new/prefix1/pic/岑宁儿 - 追光者.mp3")));
    Media->play();
}

login::~login()
{
    delete ui;
}


void login::on_checkBox_showpass_clicked(bool checked)
{
    if(checked==true)   ui->lineEdit_pass->setEchoMode(QLineEdit::Normal);
    else ui->lineEdit_pass->setEchoMode(QLineEdit::Password);
}
#include <QMessageBox>
void login::on_pushButton_login_clicked()
{
    QString user = ui->lineEdit_user->text();
    QString pass = ui->lineEdit_pass->text();

    qDebug() <<"账号：" <<user<<endl;
    qDebug() <<"密码：" <<pass<<endl;
    if(user == "2021542340225" && pass == "123456"){
        //函数栈：局部变量，会随着函数的结束而销毁.   --->堆控件变量，生命周期全局
        Func *func = new Func;
        func->show();

        this->close();
       // qDebug() <<"登陆成功" <<endl;
    }
    else {
        QMessageBox::warning(this,"登陆提示","账号密码错误，请重新登录");

        qDebug() <<"登陆失败"<<endl;}
}
