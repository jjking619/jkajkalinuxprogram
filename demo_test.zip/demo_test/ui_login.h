/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_login
{
public:
    QVBoxLayout *verticalLayout;
    QFrame *frame;
    QCheckBox *checkBox_showpass;
    QPushButton *pushButton_regist;
    QPushButton *pushButton_login;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label_user;
    QLineEdit *lineEdit_user;
    QLabel *label__pass;
    QLineEdit *lineEdit_pass;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QWidget *login)
    {
        if (login->objectName().isEmpty())
            login->setObjectName(QStringLiteral("login"));
        login->resize(799, 580);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/\347\231\273\345\275\225.png"), QSize(), QIcon::Normal, QIcon::Off);
        login->setWindowIcon(icon);
        login->setWindowOpacity(1);
        verticalLayout = new QVBoxLayout(login);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        frame = new QFrame(login);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setStyleSheet(QLatin1String("#frame{\n"
"	\n"
"	\n"
"	border-image: url(:/new/prefix1/pic/background-3.png);\n"
"}"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        checkBox_showpass = new QCheckBox(frame);
        checkBox_showpass->setObjectName(QStringLiteral("checkBox_showpass"));
        checkBox_showpass->setGeometry(QRect(210, 380, 141, 41));
        pushButton_regist = new QPushButton(frame);
        pushButton_regist->setObjectName(QStringLiteral("pushButton_regist"));
        pushButton_regist->setGeometry(QRect(210, 440, 101, 61));
        QFont font;
        font.setPointSize(15);
        pushButton_regist->setFont(font);
        pushButton_login = new QPushButton(frame);
        pushButton_login->setObjectName(QStringLiteral("pushButton_login"));
        pushButton_login->setGeometry(QRect(440, 440, 111, 61));
        pushButton_login->setFont(font);
        layoutWidget = new QWidget(frame);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(210, 260, 341, 111));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_user = new QLabel(layoutWidget);
        label_user->setObjectName(QStringLiteral("label_user"));
        QFont font1;
        font1.setPointSize(15);
        font1.setBold(true);
        font1.setWeight(75);
        label_user->setFont(font1);

        gridLayout->addWidget(label_user, 0, 0, 1, 1);

        lineEdit_user = new QLineEdit(layoutWidget);
        lineEdit_user->setObjectName(QStringLiteral("lineEdit_user"));
        lineEdit_user->setFont(font1);
        lineEdit_user->setMaxLength(32765);

        gridLayout->addWidget(lineEdit_user, 0, 1, 1, 1);

        label__pass = new QLabel(layoutWidget);
        label__pass->setObjectName(QStringLiteral("label__pass"));
        label__pass->setFont(font1);

        gridLayout->addWidget(label__pass, 1, 0, 1, 1);

        lineEdit_pass = new QLineEdit(layoutWidget);
        lineEdit_pass->setObjectName(QStringLiteral("lineEdit_pass"));
        lineEdit_pass->setFont(font1);
        lineEdit_pass->setMaxLength(32765);
        lineEdit_pass->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(lineEdit_pass, 1, 1, 1, 1);

        label = new QLabel(frame);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(250, 40, 261, 201));
        label->setStyleSheet(QString::fromUtf8("\n"
"border-image: url(:/new/prefix1/pic/\345\225\206\345\212\241\357\274\214\350\220\245\351\224\200.png);"));
        label_2 = new QLabel(frame);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(-13, -6, 801, 581));
        label_2->setStyleSheet(QStringLiteral("border-image: url(:/pic/background-3.png);"));
        label_3 = new QLabel(frame);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(290, 70, 201, 171));
        label_2->raise();
        checkBox_showpass->raise();
        pushButton_regist->raise();
        pushButton_login->raise();
        layoutWidget->raise();
        label->raise();
        label_3->raise();

        verticalLayout->addWidget(frame);


        retranslateUi(login);

        QMetaObject::connectSlotsByName(login);
    } // setupUi

    void retranslateUi(QWidget *login)
    {
        login->setWindowTitle(QApplication::translate("login", "\347\231\273\351\231\206\347\225\214\351\235\242", Q_NULLPTR));
        checkBox_showpass->setText(QApplication::translate("login", "\346\230\276\347\244\272\345\257\206\347\240\201", Q_NULLPTR));
        pushButton_regist->setText(QApplication::translate("login", "\346\263\250\345\206\214", Q_NULLPTR));
        pushButton_login->setText(QApplication::translate("login", "\347\231\273\345\275\225", Q_NULLPTR));
        label_user->setText(QApplication::translate("login", "\350\264\246\345\217\267", Q_NULLPTR));
        lineEdit_user->setText(QApplication::translate("login", "2021542340225", Q_NULLPTR));
        lineEdit_user->setPlaceholderText(QApplication::translate("login", "\350\257\267\350\276\223\345\205\245\350\264\246\345\217\267", Q_NULLPTR));
        label__pass->setText(QApplication::translate("login", "\345\257\206\347\240\201", Q_NULLPTR));
        lineEdit_pass->setText(QApplication::translate("login", "123456", Q_NULLPTR));
        lineEdit_pass->setPlaceholderText(QApplication::translate("login", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", Q_NULLPTR));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class login: public Ui_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
