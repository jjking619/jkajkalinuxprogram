#include "login.h"  //引入自己创建的头文件
#include <QApplication>   //引入qt的事件机制头文件：鼠标点击、窗口拖拽等等

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);  //创建一个事件的对象
    login w;   //创建登陆界面对象
    w.show();    //调用登陆界面的show函数
    return a.exec(); //进入事件循环
}

