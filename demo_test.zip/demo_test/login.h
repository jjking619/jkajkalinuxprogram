#ifndef LOGIN_H
#define LOGIN_H
//QWidget类是一切界面类的基类，QObject是Qt类的基类（包含信号槽机制）
#include <QWidget>
#include<QMediaPlayer>
//引入UI文件
QT_BEGIN_NAMESPACE
namespace Ui { class login; }
QT_END_NAMESPACE

//定义自己的类
class login : public QWidget//继承界面类的基类QWidget
{
    Q_OBJECT    //元对象

public:
    login(QWidget *parent = nullptr);
    ~login();

private slots:
    void on_checkBox_showpass_clicked(bool checked);

    void on_pushButton_login_clicked();

private:
    Ui::login *ui;
    QMediaPlayer *Media;
};
#endif // LOGIN_H
