﻿#include "func.h"
#include "ui_func.h"
#include <QDebug>
#include <QString>

#include <QVector>

Func::Func(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Func)
{
    ui->setupUi(this);

    ui->comboBox->addItem("RGB红灯");
    ui->comboBox->addItem("RGB绿灯");
    ui->comboBox->addItem("RGB蓝灯");

    TcpSocket = new QTcpSocket(this);
    TcpSocket_2 = new QTcpSocket(this);

    connect(TcpSocket,SIGNAL(connected()),this,SLOT(slot_connected()));
    connect(TcpSocket,SIGNAL(readyRead()),this,SLOT(slot_readyRead()));
    connect(TcpSocket_2, &QTcpSocket::readyRead,[=](){
        QByteArray data = TcpSocket_2->readAll();
        data.remove(0,1);
        //调用strtof函数，将字符数组data转换成了float类型的值，存储在变量value中。通过&endPtr获取到转换后的字符串的末尾指针
        char* endPtr;
        float value = strtof(data.constData(), &endPtr);

        ui->lineEdit_Temp->setText(data);

        seriesS->append(i,value);

        mChart = new QChart();                          //创建图标对象

        mChart->addSeries(seriesS);                  //向图表中添加系列

        mChart->createDefaultAxes();                       //创建默认的坐标，必须在addSeries之后调用

        mChart->setTheme(QChart::ChartThemeDark);           //设置图标主题

        mChart->setTitle("温度折线图");                       //设置图标名称

        chartview->setRenderHints(QPainter::Antialiasing);//消除边缘，看起来平滑一些
        // 将折线图设置给QChartView并刷新
        chartview->setChart(mChart);
        ui->horizontalLayout->addWidget(chartview);     //把chartView放到水平布局中（在ui中拖一个水平布局
        i++;
        if(i>10){
            seriesS->remove(0);
        }
    });
}

//添加监控
void Func::slot_readyRead(){
    static bool flag = false;
    static long long picsize = 0;
    if(flag==false){
        char buf[10] = "";
        TcpSocket->read(buf,10);
        picsize = atoi(buf);   //将字符串转为整型
        flag = true;
    }
    else{
        if(TcpSocket->bytesAvailable()<picsize) return ;
        char buf[picsize];
        TcpSocket->read(buf,picsize);
        QPixmap pix;
        pix.loadFromData((uchar *)buf,picsize);
        ui->label_3->setPixmap(pix);
        flag = false;
    }
}

void Func::slot_connected(){
    ui->pushButton->setEnabled(false);
}

Func::~Func()
{
    delete ui;
}

// 添加监控
void Func::on_pushButton_clicked()
{
    QString IP = ui->lineEdit->text();
    QString PORT = ui->lineEdit_2->text();
    TcpSocket->connectToHost(IP,PORT.toInt());
}
// 添加外设
void Func::on_pushButton_device_clicked()
{
    QString IP = ui->lineEdit_4->text();
    QString PORT = ui->lineEdit_3->text();
    TcpSocket_2->connectToHost(IP,PORT.toInt());
}
//开蜂鸣器
void Func::on_pushButton_openFM_clicked()
{
    unsigned char  buf[20]={0xAA,0xB2,0x00,0x01};
    TcpSocket_2->write((char*)buf,20);
    qDebug()<<buf[3]<<endl;
}
//关蜂鸣器
void Func::on_pushButton_closeFM_clicked()
{
    unsigned char buf[20]={0xAA,0xB2,0x00,0x00};
    TcpSocket_2->write((char*)buf,20);
    qDebug()<<buf[3]<<endl;
}
// LED
void Func::on_comboBox_activated(const QString &arg1)
{
    if (arg1 == "RGB红灯") { buf_LED[2] = 0x00;}
    else if (arg1 == "RGB绿灯") {buf_LED[2] = 0x01;}
    else if (arg1 == "RGB蓝灯") {buf_LED[2] = 0x02;}
}
//开LED
void Func::on_pushButton_openLED_clicked()
{
    unsigned char buf_led[] = {0xAA,0xB1,0x00,0x01};
    int id = ui->comboBox->currentIndex();
        if(id == 0);
        if(id == 1)  buf_led[2] = 0x01;
        if(id == 2)  buf_led[2] = 0x02;
    TcpSocket_2->write((char *)buf_led,sizeof(buf_led));
    qDebug()<<id<<endl;
}
//关LED
void Func::on_pushButton_closeLED_clicked()
{
    unsigned char buf_led[] = {0xAA,0xB1,0x00,0x00};
    int id = ui->comboBox->currentIndex();
        if(id == 0);
        if(id == 1)  buf_led[2] = 0x01;
        if(id == 2)  buf_led[2] = 0x02;
    TcpSocket_2->write((char *)buf_led,sizeof(buf_led));
}


// 获取温度
void Func::on_pushButton_getTem_clicked()
{
    unsigned char buf[20]={0xAA,0xB3};
    TcpSocket_2->write((char*)buf,20);
}

